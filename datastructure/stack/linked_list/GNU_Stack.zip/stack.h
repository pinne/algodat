void Push(void *x);
void *Pop(void);
int  IsEmpty(void);
int  IsFull(void);
void InitStack(int s, int m);
void FreeStack(void);

